#include "my_solver.h"
#define SOLNUMS 4
#define MATCOLS SOLNUMS
#define MATROWS SOLNUMS
#define TOLERANCE 0.0000001

double C, b, C2, b2;
double gps[4][5];
double gps2[4][5];

void hw_fcn3_1(int* n, double* x, double* fvec, double* fjac, int* ldfjac, int* iflag)
{
	// origin function F(x)
	if (*iflag == 1) {
		/********************************/

		fvec[0] = pow(x[0] - gps[0][0], 2.0) + pow(x[1] - gps[0][1], 2.0) + pow(x[2] - gps[0][2], 2.0) - pow(C * (gps[0][4] + x[3] - gps[0][3]), 2.0);

		fvec[1] = pow(x[0] - gps[1][0], 2.0) + pow(x[1] - gps[1][1], 2.0) + pow(x[2] - gps[1][2], 2.0) - pow(C * (gps[1][4] + x[3] - gps[1][3]), 2.0);

		fvec[2] = pow(x[0] - gps[2][0], 2.0) + pow(x[1] - gps[2][1], 2.0) + pow(x[2] - gps[2][2], 2.0) - pow(C * (gps[2][4] + x[3] - gps[2][3]), 2.0);

		fvec[3] = pow(x[0] - gps[3][0], 2.0) + pow(x[1] - gps[3][1], 2.0) + pow(x[2] - gps[3][2], 2.0) - pow(C * (gps[3][4] + x[3] - gps[3][3]), 2.0);


		/********************************/
	}
	// Jacobi matrix J(x)
	else if (*iflag == 2) {
		/********************************/

		fjac[0] = 2.0 * (x[0] - gps[0][0]);	fjac[4] = 2.0 * (x[1] - gps[0][1]);	fjac[8] = 2.0 * (x[2] - gps[0][2]);	fjac[12] = (-2.0) * C * C * (gps[0][4] + x[3] - gps[0][3]);

		fjac[1] = 2.0 * (x[0] - gps[1][0]);	fjac[5] = 2.0 * (x[1] - gps[1][1]);	fjac[9] = 2.0 * (x[2] - gps[1][2]);	fjac[13] = (-2.0) * C * C * (gps[1][4] + x[3] - gps[1][3]);

		fjac[2] = 2.0 * (x[0] - gps[2][0]);	fjac[6] = 2.0 * (x[1] - gps[2][1]);	fjac[10] = 2.0 * (x[2] - gps[2][2]);	fjac[14] = (-2.0) * C * C * (gps[2][4] + x[3] - gps[2][3]);

		fjac[3] = 2.0 * (x[0] - gps[3][0]);	fjac[7] = 2.0 * (x[1] - gps[3][1]);	fjac[11] = 2.0 * (x[2] - gps[3][2]);	fjac[15] = (-2.0) * C * C * (gps[3][4] + x[3] - gps[3][3]);

		/********************************/
	}
}

void hw_fcn3_1_2(int* n, double* x, double* fvec, int* iflag) {
	fvec[0] = pow(x[0] - gps2[0][0], 2.0) + pow(x[1] - gps2[0][1], 2.0) + pow(x[2] - gps2[0][2], 2.0) - pow(C2 * (gps2[0][4] + x[3] - gps2[0][3]), 2.0);
	fvec[1] = pow(x[0] - gps2[1][0], 2.0) + pow(x[1] - gps2[1][1], 2.0) + pow(x[2] - gps2[1][2], 2.0) - pow(C2 * (gps2[1][4] + x[3] - gps2[1][3]), 2.0);
	fvec[2] = pow(x[0] - gps2[2][0], 2.0) + pow(x[1] - gps2[2][1], 2.0) + pow(x[2] - gps2[2][2], 2.0) - pow(C2 * (gps2[2][4] + x[3] - gps2[2][3]), 2.0);
	fvec[3] = pow(x[0] - gps2[3][0], 2.0) + pow(x[1] - gps2[3][1], 2.0) + pow(x[2] - gps2[3][2], 2.0) - pow(C2 * (gps2[3][4] + x[3] - gps2[3][3]), 2.0);

}

void hw3_1_1() {
	char readfile[256];
	char writefile[256];

	int n = SOLNUMS;
	double x[SOLNUMS];	
	double fvec[SOLNUMS], fjac[MATCOLS * MATROWS];
	int ldfjac = SOLNUMS;
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (SOLNUMS + 13)) / 2;
	double fabs_x[SOLNUMS];

	for (int t = 0; t <= 2; t++) {

		sprintf(readfile, "GPS_signal_%d.txt", t);
		sprintf(writefile, "GPS_position_3-1_%d.txt", t);

		FILE* fp_r = fopen(readfile, "r");
		if (fp_r == NULL) {
			printf("%s file open error...\n", readfile);
			return;
		}

		FILE* fp_w = fopen(writefile, "w");
		if (fp_w == NULL) {
			printf("%s file open error...\n", writefile);
			return;
		}

		fscanf(fp_r, "%lf %lf", &C, &b);
		for (int i = 0; i < 4; i++) {
			fscanf(fp_r, "%lf %lf %lf %lf %lf", &gps[i][0], &gps[i][1], &gps[i][2], &gps[i][3], &gps[i][4]);
		}
		
		printf("%d. hw3-1-1(x1,x2,x3) : ", t+1);
		scanf("%lf %lf %lf", &x[0], &x[1], &x[2]);
		x[3] = b;

		fprintf(fp_w, "Initial: %.15lf, %.15lf, %.15lf, %.15f\n", x[0], x[1], x[2], x[3]);

		hybrj1_(hw_fcn3_1, &n, x, fvec, fjac, &ldfjac, &tol, &info, wa, &lwa);

		if (info != 1)
			fprintf(fp_w, "wrong\n");

		fprintf(fp_w, "x1 = %.15lf, x2 = %.15lf, x3 =  %.15lf, x4 = %.15f\n", x[0], x[1], x[2], x[3]);

		fabs_x[0] = pow(x[0] - gps[0][0], 2.0) + pow(x[1] - gps[0][1], 2.0) + pow(x[2] - gps[0][2], 2.0) - pow(C * (gps[0][4] + x[3] - gps[0][3]), 2.0);
		fabs_x[1] = pow(x[0] - gps[1][0], 2.0) + pow(x[1] - gps[1][1], 2.0) + pow(x[2] - gps[1][2], 2.0) - pow(C * (gps[1][4] + x[3] - gps[1][3]), 2.0);
		fabs_x[2] = pow(x[0] - gps[2][0], 2.0) + pow(x[1] - gps[2][1], 2.0) + pow(x[2] - gps[2][2], 2.0) - pow(C * (gps[2][4] + x[3] - gps[2][3]), 2.0);
		fabs_x[3] = pow(x[0] - gps[3][0], 2.0) + pow(x[1] - gps[3][1], 2.0) + pow(x[2] - gps[3][2], 2.0) - pow(C * (gps[3][4] + x[3] - gps[3][3]), 2.0);

		fabs_x[0] = fabs(fabs_x[0]);
		fabs_x[1] = fabs(fabs_x[1]);
		fabs_x[2] = fabs(fabs_x[2]);
		fabs_x[3] = fabs(fabs_x[3]);

		fprintf(fp_w, "|f1()| = %.15lf\n", fabs_x[0]);
		fprintf(fp_w, "|f2()| = %.15lf\n", fabs_x[1]);
		fprintf(fp_w, "|f3()| = %.15lf\n", fabs_x[2]);
		fprintf(fp_w, "|f3()| = %.15lf\n", fabs_x[3]);
		fprintf(fp_w, "\n");

		if (fp_r != NULL) fclose(fp_r);
		if (fp_w != NULL) fclose(fp_w);
	}
}

void hw3_1_2(void)
{
	char readfile[256];
	char writefile[256];
	int n = SOLNUMS;
	double x[SOLNUMS];	
	double fvec[SOLNUMS];
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (3 * SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (3 * SOLNUMS + 13)) / 2;
	double fabs_x[SOLNUMS];

	for (int t = 0; t < 3; t++) {

		sprintf(readfile, "GPS_signal_%d.txt", t);
		sprintf(writefile, "GPS_position_3-2_%d.txt", t);

		FILE* fp_r = fopen(readfile, "r");
		if (fp_r == NULL) {
			printf("%s file open error...\n", readfile);
			return;
		}

		FILE* fp_w = fopen(writefile, "w");
		if (fp_w == NULL) {
			printf("%s file open error...\n", writefile);
			return;
		}

		fscanf(fp_r, "%lf %lf", &C2, &b2);
		for (int i = 0; i < 4; i++) {
			fscanf(fp_r, "%lf %lf %lf %lf %lf", &gps2[i][0], &gps2[i][1], &gps2[i][2], &gps2[i][3], &gps2[i][4]);
		}

		printf("%d. hw3-1-2(x1,x2,x3) : ", t+1);
		scanf("%lf %lf %lf", &x[0], &x[1], &x[2]);
		x[3] = b;

		fprintf(fp_w, "Initial: %.15lf, %.15lf, %.15lf, %.15f\n", x[0], x[1], x[2], x[3]);

		hybrd1_(hw_fcn3_1_2, &n, x, fvec, &tol, &info, wa, &lwa);


		if (info != 1)
			fprintf(fp_w, "wrong\n");

		fprintf(fp_w, "x1 = %.15lf, x2 = %.15lf, x3 =  %.15lf, x4 = %.15f\n", x[0], x[1], x[2], x[3]);

		fabs_x[0] = pow(x[0] - gps2[0][0], 2.0) + pow(x[1] - gps2[0][1], 2.0) + pow(x[2] - gps2[0][2], 2.0) - pow(C2 * (gps2[0][4] + x[3] - gps2[0][3]), 2.0);
		fabs_x[1] = pow(x[0] - gps2[1][0], 2.0) + pow(x[1] - gps2[1][1], 2.0) + pow(x[2] - gps2[1][2], 2.0) - pow(C2 * (gps2[1][4] + x[3] - gps2[1][3]), 2.0);
		fabs_x[2] = pow(x[0] - gps2[2][0], 2.0) + pow(x[1] - gps2[2][1], 2.0) + pow(x[2] - gps2[2][2], 2.0) - pow(C2 * (gps2[2][4] + x[3] - gps2[2][3]), 2.0);
		fabs_x[3] = pow(x[0] - gps2[3][0], 2.0) + pow(x[1] - gps2[3][1], 2.0) + pow(x[2] - gps2[3][2], 2.0) - pow(C2 * (gps2[3][4] + x[3] - gps2[3][3]), 2.0);


		fabs_x[0] = fabs(fabs_x[0]);
		fabs_x[1] = fabs(fabs_x[1]);
		fabs_x[2] = fabs(fabs_x[2]);
		fabs_x[3] = fabs(fabs_x[3]);

		fprintf(fp_w, "|f1()| = %.15lf\n", fabs_x[0]);
		fprintf(fp_w, "|f2()| = %.15lf\n", fabs_x[1]);
		fprintf(fp_w, "|f3()| = %.15lf\n", fabs_x[2]);
		fprintf(fp_w, "|f3()| = %.15lf\n", fabs_x[3]);
		fprintf(fp_w, "\n");

		if (fp_r != NULL) fclose(fp_r);
		if (fp_w != NULL) fclose(fp_w);
	}

}