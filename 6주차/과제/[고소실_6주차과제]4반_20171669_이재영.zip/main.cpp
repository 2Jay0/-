﻿#include "my_solver.h"

int main(void)
{
    hw3_1_1();
    hw3_1_2();
    hw3_2();
    hw3_3();
    hw3_4();
    return 0;
}
