#include "my_solver.h"
#include <math.h>
#include <time.h>
#include <stdlib.h>

double _fp_a(double x0, double* arr_x, double* arr_y, int num, double u) {
	int i;
	double result = 0.0;
	double s;

	for (i = 0; i < num - 1; i++) {
		if (arr_x[i] > x0)
			break;
	}
	if (i == num - 1)
		i--;

	s = (x0 - arr_x[i]) / (arr_x[i + 1] - arr_x[i]);
	result = arr_y[i] * (1.0 - s) + (arr_y[i + 1] * s);

	return result;
}

double _f_a(double x1, double* arr_x, int num, double* integral, double u) {
	int i;
	double result = 0.0;

	for (i = 0; i < num - 1; i++) {
		if (arr_x[i] > x1)
			break;
	}
	if (i == num - 1)
		i--;
	result = integral[i] + (integral[i + 1] - integral[i]) * ((x1 - arr_x[i]) / (arr_x[i + 1] - arr_x[i]));

	return result - u;
}
// HOMEWORK
void program2_3()
{
	FILE* pdf, * random;
	FILE* histo;
	int num, rand_num;
	double h;

	pdf = fopen("pdf_table.txt", "r");
	random = fopen("random_event_table.txt", "r");
	histo = fopen("histogram.txt", "w");

	fscanf(pdf, "%d %lf", &num, &h);
	fscanf(random, "%d", &rand_num);

	int* histogram = (int*)calloc(num,sizeof(int));
	double* arr_x = (double*)malloc(sizeof(double) * num);
	double* arr_y = (double*)malloc(sizeof(double) * num);

	for (int i = 0; i < num; i++)
		fscanf(pdf, "%lf %lf", &arr_x[i], &arr_y[i]);

	double* rand_val = (double*)malloc(sizeof(double) * rand_num);
	
	for (int i = 0; i < rand_num; i++)
		fscanf(random, "%lf", &rand_val[i]);

	for (int i = 0; i < rand_num; i++)
		histogram[(int)(rand_val[i] * 100)]++;

	int check_sum = 0;
	for (int i = 0; i < num; i++)
	{
		check_sum += histogram[i];
		fprintf(histo, "%d %d\n", i, histogram[i]);
	}

	free(arr_x);
	free(arr_y);
	free(rand_val);
	free(histogram);

	fclose(pdf);
	fclose(random);
	fclose(histo);
}

void check2_2_b()
{
	FILE* pdf, * random;
	FILE* histo;
	int num, rand_num;
	double h;

	pdf = fopen("pdf_table.txt", "r");
	random = fopen("random_event_table_2_2_b.txt", "r");
	histo = fopen("histogram2-2_b.txt", "w");

	fscanf(pdf, "%d %lf", &num, &h);
	fscanf(random, "%d", &rand_num);

	int* histogram = (int*)calloc(num, sizeof(int));
	double* arr_x = (double*)malloc(sizeof(double) * num);
	double* arr_y = (double*)malloc(sizeof(double) * num);

	for (int i = 0; i < num; i++)
		fscanf(pdf, "%lf %lf", &arr_x[i], &arr_y[i]);

	double* rand_val = (double*)malloc(sizeof(double) * rand_num);

	for (int i = 0; i < rand_num; i++)
		fscanf(random, "%lf", &rand_val[i]);

	for (int i = 0; i < rand_num; i++)
		histogram[(int)(rand_val[i] * 100)]++;

	int check_sum = 0;
	for (int i = 0; i < num; i++)
	{
		check_sum += histogram[i];
		fprintf(histo, "%d %d\n", i, histogram[i]);
	}

	free(arr_x);
	free(arr_y);
	free(rand_val);
	free(histogram);

	fclose(pdf);
	fclose(random);
	fclose(histo);
}
// HOMEWORK
void program2_2_a()
{
	__int64 start, freq, end;
	float resultTime = 0;
	FILE* fp_r, * fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table_2-2_a.txt", "w");

	int num;
	double h, U;
	double a0, b0, x0, x1;
	int rand_num;

	printf("program2_2_a(bisection) random number : ");
	scanf("%d", &rand_num);
	fprintf(fp_w, "%d\n", rand_num);
	fscanf(fp_r, "%d %lf\n", &num, &h);

	double* arr_x = (double*)malloc(sizeof(double) * num);
	double* arr_y = (double*)malloc(sizeof(double) * num);

	for (int i = 0; i < num; i++)
		fscanf(fp_r, "%lf %lf\n", &arr_x[i], &arr_y[i]);

	double* tot_sum = (double*)malloc(sizeof(double) * num);

	tot_sum[0] = 0;
	for (int i = 1; i < num; i++)
		tot_sum[i] = tot_sum[i - 1] + (arr_y[i] + arr_y[i - 1]) * (h / 2);

	srand(time(NULL));

	CHECK_TIME_START;

	for (int i = 0; i < rand_num; i++)
	{
		U = (double)rand() / RAND_MAX;
		a0 = 0.0;
		b0 = 1.0;
		int n = 0;
		//x0 = 1.797693134e+308;
		x0 = 0;
		x1 = (a0 + b0) / 2;

		while (1)
		{
			if (_f_a(a0, arr_x, num, tot_sum, U) * _f_a(x1, arr_x, num, tot_sum, U) < 0)
				b0 = x1;
			else
				a0 = x1;

			if (fabs(_f_a(x1, arr_x, num, tot_sum, U)) < DELTA)
				break;
			if (n >= Nmax)
				break;
			if(fabs(x0 - x1) < EPSILON)
				break;

			x0 = x1;
			x1 = (a0 + b0) / 2;
			n++;
		}
		fprintf(fp_w, "%.15lf\n", x1);
	}

	CHECK_TIME_END(resultTime);

	free(arr_x);
	free(arr_y);
	free(tot_sum);


	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);

	printf("The program2_2_a(bisection) run time is %f(ms)..\n", resultTime * 1000.0);
}

void program2_2_b()
{
	__int64 start, freq, end;
	float resultTime = 0;


	FILE* fp_r, * fp_w;
	int rand_num, num, n;
	double h, U;
	double a0, b0, x0, x1, temp;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table_2_2_b.txt", "w");

	printf("program2_2_b(secant) random number : ");
	scanf("%d", &rand_num);
	fprintf(fp_w, "%d\n", rand_num);
	fscanf(fp_r, "%d %lf\n", &num, &h);

	double* arr_x = (double*)malloc(sizeof(double) * num);
	double* arr_y = (double*)malloc(sizeof(double) * num);

	for (int i = 0; i < num; i++)
		fscanf(fp_r, "%lf %lf\n", &arr_x[i], &arr_y[i]);

	double* tot_sum = (double*)malloc(sizeof(double) * num);
	tot_sum[0] = 0;
	for (int i = 1; i < num; i++)
		tot_sum[i] = tot_sum[i - 1] + (arr_y[i] + arr_y[i - 1]) * (h / 2);
	srand(time(NULL));

	CHECK_TIME_START;

	for (int i = 0; i < rand_num; i++) {
		U = (double)rand() / RAND_MAX;

		a0 = 0.0;
		b0 = 1.0;
		x1 = (a0 + b0) / 2.0;
		x0 = 0;
		n = 0;



		while (1) {
			if (_f_a(a0, arr_x, num, tot_sum, U) * _f_a(x1, arr_x, num, tot_sum, U) < 0) {
				b0 = x1;
			}
			else {
				a0 = x1;
			}

			if (fabs(_f_a(x1, arr_x, num, tot_sum, U)) < DELTA) {
				break;
			}
			if (n > 3) {
				break;
			}
			if (fabs(x0 - x1) < EPSILON) {
				break;
			}

			x0 = x1;
			x1 = (a0 + b0) / 2.0;
			n++;
		}

		if (fabs(_f_a(x1, arr_x, num, tot_sum, U)) < DELTA) {

			fprintf(fp_w, "%.15lf\n", x1);
			continue;
		}
		if (fabs(x0 - x1) < EPSILON) {

			fprintf(fp_w, "%.15lf\n", x1);
			continue;
		}

		n = 0;

		while (1) {
			if (fabs(_f_a(x1, arr_x, num, tot_sum, U)) < DELTA) {
				break;
			}
			if (n >= Nmax) {
				break;
			}
			if (fabs(x0 - x1) < EPSILON) {
				break;
			}

			temp = x0;
			x0 = x1;

			x1 = x1 - _f_a(x1, arr_x, num, tot_sum, U) * ((x1 - temp) / (_f_a(x1, arr_x, num, tot_sum, U) - _f_a(temp, arr_x, num, tot_sum, U)));
			n++;

			if (x1 > 1.0)
				x1 = 1.0;
		}
		fprintf(fp_w, "%.15lf\n", x1);

	}

	CHECK_TIME_END(resultTime);

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);

	printf("The program2_2_b(secant) run time is %f(ms)..\n", resultTime * 1000.0);
}

void program2_2_c()
{
	__int64 start, freq, end;
	float resultTime = 0;

	FILE* fp_r, * fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table_2_2_c.txt", "w");

	int num;
	double h, U;
	int rand_num;
	double x0, x1, temp;

	printf("program2_2_c(newton) random number : ");
	scanf("%d", &rand_num);
	fprintf(fp_w, "%d\n", rand_num);
	fscanf(fp_r, "%d %lf\n", &num, &h);

	double* arr_x = (double*)malloc(sizeof(double) * num);
	double* arr_y = (double*)malloc(sizeof(double) * num);

	for (int i = 0; i < num; i++)
		fscanf(fp_r, "%lf %lf\n", &arr_x[i], &arr_y[i]);

	double* tot_sum = (double*)malloc(sizeof(double) * num);

	tot_sum[0] = 0;
	for (int i = 1; i < num; i++)
		tot_sum[i] = tot_sum[i - 1] + (arr_y[i] + arr_y[i - 1]) * (h / 2);

	/// //////////////////////

	srand(time(NULL));

	CHECK_TIME_START;

	for (int i = 0; i < rand_num; i++) {
		U = (double)rand() / RAND_MAX;

		int n = 0;
		x1 = U;
		x0 = 0;
		
		while (1) {
			if (fabs(_f_a(x1, arr_x, num, tot_sum, U)) < DELTA) {
				break;
			}
			if (n >= Nmax) {
				break;
			}
			if (fabs(x0 - x1) < EPSILON) {
				break;
			}

			x0 = x1;
			x1 = x0 - _f_a(x0, arr_x, num, tot_sum, U) / _fp_a(x0, arr_x, arr_y,num, U);
			n++;

			if (x1 > 1.0)
				x1 = 1.0;
		}
		fprintf(fp_w, "%.15lf\n", x1);
	
	}
	

	free(arr_x);
	free(arr_y);
	free(tot_sum);

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
	CHECK_TIME_END(resultTime);

	printf("The program2_2_c(newton) run time is %f(ms)..\n", resultTime * 1000.0);
}

double variance(double* res, int n, double avg) {
	double var = 0;
	for (int i = 0; i < n; i++)
		var += ((res[i] - avg) * (res[i] - avg));

	return var / (double)n;
}

double average(double* res, int n) {
	double avg = 0;
	for (int i = 0; i < n; i++)
		avg += res[i];

	return avg / (double)(n - 1);
}

void Test2_1()
{
	double lam[3] = { 2.0,4.0,5.0 };
	int rand_num;
	double U;
	double temp, avg, var;

	srand(time(NULL));

	printf("Test2_1 random number : ");
	scanf("%d", &rand_num);

	double* res = (double*)malloc(sizeof(double) * rand_num);

	for (int k = 0; k < 3; k++)
	{
		for (int i = 0; i < rand_num; i++)
		{
			U = (double)rand() / RAND_MAX;
			double a = 0.0;
			double b = 20.0;
			double x0, x1, ya, yb;
			x0 = 100;
			x1 = a - b / 2;
			int n = 0;

			while(1)
			{
				if (fabs((1 - exp((-1) * lam[k] * x1)) - U) < DELTA)
					break;
				if (n >=Nmax)
					break;
				if (fabs(x0 - x1) < EPSILON)
					break;

				temp = (1 - exp((-1) * lam[k] * x1)) - U;
				ya = (1 - exp((-1) * lam[k] * a)) - U;
				yb = (1 - exp((-1) * lam[k] * b)) - U;
				if (ya * temp < 0) {
					b = x1;
					yb = temp;
				}
				else if (yb * temp < 0) {
					a = x1;
					ya = temp;
				}

				x0 = x1;
				x1 = (a + b) / 2.0;
			}
			res[i] = x1;
		}
		avg = average(res, rand_num);
		var = variance(res, rand_num, avg);

		printf("%d. lambda(num) %lf : \n", k+1,lam[k]);
		printf("[Result]\n");
		printf("Average : %lf\nVariance : %lf\n", avg, var);
		printf("[Difference]\n");
		printf("Average difference : %lf%\nvariance difference : %lf%\n", fabs(1.0 / lam[k] - avg), fabs((1.0 / (lam[k] * lam[k])) - var));
		printf("\n");
	}
}