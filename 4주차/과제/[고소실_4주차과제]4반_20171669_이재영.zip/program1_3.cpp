#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Bisection Method -- HOMEWORK
**********************************************/
void program1_3(FILE *fp)
{
	double a0, b0, x0, x1 , temp;
	x0 = DBL_MAX;
	int n=0;

	if (fp == NULL)
		return;

	fprintf(fp, " n              xn1                           |f(xn1)|\n");
	scanf("%lf %lf", &a0, &b0);

	while (1)
	{
		x1 = (a0 + b0) / 2;
		fprintf(fp, "%2d  %20.18e  %12.10e\n", n, x1, fabs(_f(x1)));
		if (_f(a0) * _f(x1) < 0) //������ b0�� �߰� ����� a0�� �߰�
			b0 = x1;
		else
			a0 = x1;

		if (fabs(_f(x1)) < DELTA || fabs(x1-x0) < EPSILON || n >= Nmax)
			break;

		x0 = x1;
		n++;
	}
	printf("%2d  %20.18e  %12.10e\n", n, x1, fabs(_f(x1)));
}