#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Newton-Rapson Method
**********************************************/
void program1_1(FILE* fp) {
	double x0, x1;
	x0 = DBL_MAX;
	int n = 0;

	if (fp == NULL)
		return;

	fprintf(fp, " n              xn1                           |f(xn1)|\n");
	scanf("%lf", &x1);

	while (1)
	{
		fprintf(fp, "%2d  %20.18e  %12.10e\n", n, x1, fabs(_f(x1)));

		if (fabs(_f(x1)) < DELTA || n >= Nmax || fabs(x1 - x0) < EPSILON)
			break;
		x0 = x1;
		x1 = x0 - (_f(x0) / _fp(x0));

		n++;
	}
	printf("%2d  %20.18e  %12.10e\n", n, x1, fabs(_f(x1)));
}
