#include "my_solver.h"
#include <time.h>
#include <math.h>
#include <stdlib.h>
#define RADN_MAX 32767
double* U;

double _f(double x1, double* arr_x, double* arr_y, int num, double* total_sum, double u) 
{
	int i;
	double result = 0.0;
	for (i = 0; i < num - 1; i++) {
		if (arr_x[i] > x1)
			break;
	}
	result = total_sum[i] + (((arr_y[i + 1] - arr_y[i]) / (arr_x[i + 1] - arr_x[i])) * ((x1 - arr_x[i]) / 2)) * (x1 - arr_x[i]);
	return result - u;
}

void my_func(int m) {
	int i = 0;
	unsigned int iseed = (unsigned int)time(NULL);
	srand(iseed);
	while (i < m) {
		U[i] = (double)rand() / RAND_MAX;
		i++;
	}
}

void program2_2()
{
	FILE* fp_r, *fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table.txt", "w");

	/***************************************************/
	int num;
	double h;
	int rand_num;

	scanf("%d", &rand_num);
	fscanf(fp_r, "%d %lf\n", &num, &h);

	U = (double*)malloc(sizeof(double) * rand_num);
	double* arr_x = (double*)malloc(sizeof(double) * num);
	double* arr_y = (double*)malloc(sizeof(double) * num);

	for (int i = 0; i < num; i++)
	{
		fscanf(fp_r, "%lf %lf\n", &arr_x[i], &arr_y[i]);
	}

	double* tot_sum = (double*)malloc(sizeof(double) * num);

	tot_sum[0] = 0;
	for (int i = 1; i < num; i++)
	{
		tot_sum[i] = tot_sum[i - 1] + (arr_y[i] + arr_y[i - 1]) * (h / 2);
	}

	double check;
	int index = 0;
	my_func(rand_num);
	fprintf(fp_w, "%d\n", rand_num);
	for (int i = 0; i < rand_num; i++)
	{		
		double a0 = 0.0;
		double b0 = 1.0;
		int n = 0;
		double x0, x1;
		x0 = 0;

		while (1)
		{
			x1 = (a0 + b0) / 2;

			if(_f(a0, arr_x, arr_y, num, tot_sum, U[i]) * _f(x1, arr_x, arr_y, num, tot_sum, U[i])<0)
				b0 = x1;
			else
				a0 = x1;

			if (fabs(_f(x1, arr_x, arr_y, num, tot_sum, U[i])) < DELTA || fabs(x1 - x0) < EPSILON || n >= Nmax)
				break;

			x0 = x1;
			n++;
		}
		
		fprintf(fp_w, "%.15lf\n", x1);
	}

	
	free(arr_x);
	free(arr_y);
	free(tot_sum);

	/***************************************************/

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
}
