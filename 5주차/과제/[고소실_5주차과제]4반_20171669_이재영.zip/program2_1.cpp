#include "my_solver.h"

void program2_1()
{
	FILE* fp_r, *fp_w;
	__int64 start, freq, end;
	float resultTime = 0;

	fp_r = fopen("sampling_table.txt", "r");
	if (fp_r == NULL) {
		printf("input file not found....\n");
		exit(0);
	}

	fp_w = fopen("pdf_table.txt", "w");

	/***************************************************/

	int num;
	double h;

	fscanf(fp_r, "%d %lf\n", &num, &h);

	double* arr_x = (double*)malloc(sizeof(double) * num);
	double* arr_y = (double*)malloc(sizeof(double) * num);
	double* res_x = (double*)malloc(sizeof(double) * num);
	double* res_y = (double*)malloc(sizeof(double) * num);

	for (int i = 0; i < num; i++)
	{
		fscanf(fp_r, "%lf %lf\n", &arr_x[i], &arr_y[i]);
	}

	double total;
	double sum = 0.0;
	for (int j = 1; j <= num - 2; j++)
		sum += arr_y[j];

	total = (((float)1 / num) / 2) * (arr_y[0] + 2 * sum + arr_y[num - 1]); //h�� �ٲ� �׷����� ����

	for (int i = 0; i < num; i++)
	{
		res_x[i] = (arr_x[i] - arr_x[0]) / (arr_x[num - 1] - arr_x[0]);
		res_y[i] = arr_y[i] / total;
	}

	fprintf(fp_w, "%d %lf\n", num, res_x[1] - res_x[0]);
	for (int i = 0; i < num; i++)
		fprintf(fp_w, "%lf %lf\n", res_x[i], res_y[i]);

	double check;
	double sum_new = 0.0;
	for (int j = 1; j <= num - 2; j++)
		sum_new += res_y[j];

	check = (((res_x[num - 1] - res_x[0]) / num) / 2) * (res_y[0] + 2 * sum_new + res_y[num - 1]);
	printf("***Integrating the pdf from 0.0 to 1.0 = %lf\n", check);

	int k = 0;
	int first = k;
	sum_new = 0.0;
	while (res_x[k] < 0.25) {
		sum_new += res_y[k];
		k++;
	}

	check = (((res_x[num - 1] - res_x[0]) / num) / 2) * (res_y[first] + 2 * sum_new + res_y[k]);
	printf("***Integrating the pdf from 0.0 to 0.25 = %lf\n", check);

	sum_new = 0.0;
	first = k++;


	while (res_x[k] < 0.5) {
		sum_new += res_y[k];
		k++;
	}
	
	check = (((res_x[num - 1] - res_x[0]) / num) / 2) * (res_y[first] + 2 * sum_new + res_y[k]);
	printf("***Integrating the pdf from 0.25 to 0.5 = %lf\n", check);

	sum_new = 0.0;
	first = k++;

	while (res_x[k] < 0.75) {
		sum_new += res_y[k];
		k++;
	}

	check = (((res_x[num - 1] - res_x[0]) / num) / 2) * (res_y[first] + 2 * sum_new + res_y[k]);
	printf("***Integrating the pdf from 0.5 to 0.75 = %lf\n", check);


	sum_new = 0.0;
	first = k++;

	while (res_x[k] < 1.0) {
		sum_new += res_y[k];
		k++;
	}

	check = (((res_x[num - 1] - res_x[0]) / num) / 2) * (res_y[first] + 2 * sum_new + res_y[k]);
	printf("***Integrating the pdf from 0.75 to 1.0 = %lf\n", check);


	free(arr_x);
	free(arr_y);
	free(res_x);
	free(res_y);
	/***************************************************/

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
}
