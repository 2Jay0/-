#include "my_solver.h"

#define SOLNUMS 3
#define MATCOLS SOLNUMS
#define MATROWS SOLNUMS
#define TOLERANCE 0.0000001


void hw3_4(void) {
	FILE* fp_r = fopen("linear_system_3-4.txt", "r");
	FILE* fp_w = fopen("solution_3-4.txt", "w");

	int n, i, j, ia, * l;

	float* a, * b, * x, * s, * vari;

	fscanf(fp_r, "%d", &n);

	a = (float*)malloc(sizeof(float*) * n * n);
	b = (float*)malloc(sizeof(float) * n);
	x = (float*)malloc(sizeof(float) * n);
	s = (float*)malloc(sizeof(float) * n);
	vari = (float*)malloc(sizeof(float) * n);
	l = (int*)malloc(sizeof(int) * n);

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			fscanf(fp_r, "%f", &a[j * n + i]);
		}
	}

	for (i = 0; i < n; i++) {
		fscanf(fp_r, "%f", &b[i]);

	}
	ia = n;

	gespp_(&n, a, &ia, l, s);
	solve_(&n, a, &ia, l, b, x);

	fprintf(fp_w, "%d\n", n);

	for (i = 0; i < n; i++)
		fprintf(fp_w, "%f\n", x[i]);

	fclose(fp_r);
	fp_r = fopen("linear_system_3-4.txt", "r");

	fscanf(fp_r, "%d", &n);

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			fscanf(fp_r, "%f", &a[j * n + i]);
		}
	}
	for (i = 0; i < n; i++) {
		fscanf(fp_r, "%f", &b[i]);

	}

	float temp = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++)
			temp = temp + a[n * j + i] * x[j];

		temp = temp - b[i];
		temp = fabs(temp);
		temp = temp / fabs(b[i]);

		vari[i] = temp;
	}
	temp = 0;
	for (i = 0; i < n; i++) {
		temp += vari[i];
	}
	temp /= n;
	fprintf(fp_w, "%f\n", temp);
}
