#include <stdio.h>
#include <string.h>
#include <random>
#include <time.h>

#include <math.h>
#include <time.h>
#include <Windows.h>

__int64 start, freq, end;
#define CHECK_TIME_START QueryPerformanceFrequency((LARGE_INTEGER*)&freq); QueryPerformanceCounter((LARGE_INTEGER*)&start)
#define CHECK_TIME_END(a) QueryPerformanceCounter((LARGE_INTEGER*)&end); a = (float)((float)(end - start) / (freq / 1000.0f))
float compute_time;
float compute_time1, compute_time2;

#define ARRAY_SIZE 100000
#define MATDIM 1024
#define HW1_N 1500
float *hw1_x, hw1_E, hw1_var1, hw1_var2;
float hw2_a, hw2_b, hw2_c, hw2_naive_ans[2], hw2_pre_ans[2];

/* hw1 */
void init_hw1(int fixed);
void hw1_calc_e();
void hw1_calc_var1();
void hw1_calc_var2();
/* hw2 */
void hw2_naive();
void hw2_safe();
float hw2_verify(float x);
/* hw3 */
void hw3_1(void);
void hw3_2(void);
void hw3_3(void);
void hw3_4(void);
void hw3_5(void);

float Arr_global[ARRAY_SIZE];


void main(void)
{
	srand((unsigned)time(NULL));

	/* hw1 */
	puts("====== hw1 ======");
	init_hw1(1);

	hw1_calc_e();

	CHECK_TIME_START;
	hw1_calc_var1();
	CHECK_TIME_END(compute_time);
	compute_time1 = compute_time;
	printf("hw1_calc_var1 = %f ms\n", compute_time);
	printf("hw1_calc_var1 value = %.15f\n", hw1_var1);


	CHECK_TIME_START;
	hw1_calc_var2();
	CHECK_TIME_END(compute_time);
	compute_time2 = compute_time;
	printf("hw1_calc_var2 = %f ms\n", compute_time);
	printf("hw1_calc_var2 value = %.15f\n", hw1_var2);
	puts("");
	
	/* hw2 */
	
	puts("====== hw2 ======");
	printf("a, b, c : ");
	scanf("%f %f %f", &hw2_a, &hw2_b, &hw2_c);
	hw2_naive();
	hw2_safe();
	printf("naive result    : %.15f, %.15f\n", hw2_naive_ans[0], hw2_naive_ans[1]);
	printf("advanced result : %.15f, %.15f\n", hw2_pre_ans[0], hw2_pre_ans[1]);
	puts("");
	printf("Verifying naive ans    : %.15f, %.15f\n", hw2_verify(hw2_naive_ans[0]), hw2_verify(hw2_naive_ans[1]));
	printf("Verifying advanced ans : %.15f, %.15f\n", hw2_verify(hw2_pre_ans[0]), hw2_verify(hw2_pre_ans[1]));
	puts("");
	
	/* hw3 */
	hw3_1();
	hw3_2();
	hw3_3();
	hw3_4();
	hw3_5();

}

void init_hw1(int fixed)
{
	float *ptr;
	hw1_x = (float *)malloc(sizeof(float)*HW1_N);

	if (fixed)
	{
		float tmp = HW1_N;
		for (int i = 0; i < HW1_N; i++)
		{
			if( i & 1) tmp -= 0.0001;
			hw1_x[i] = tmp;
		}
	}
	else
	{
		srand((unsigned)time(NULL));
		ptr = hw1_x;
		for (int i = 0; i < HW1_N; i++)
			*ptr++ = ((float)rand() / (float)RAND_MAX) * 2;
	}
}
void hw1_calc_e()
{
	for (int i = 0; i < HW1_N; i++) {
		hw1_E += hw1_x[i];
	}
	hw1_E /= HW1_N;
}
void hw1_calc_var1()
{
	double sum = 0;
	for (int i = 0; i < HW1_N; i++)
		sum = sum + (hw1_x[i] - hw1_E) * (hw1_x[i] - hw1_E);
	sum = sum / (HW1_N - 1);
	hw1_var1 = sum;
}
void hw1_calc_var2()
{
	double temp1 = 0, temp2 = 0, result = 0;

	for (int i = 0; i < HW1_N; i++) {
		temp1 += hw1_x[i] * hw1_x[i];
		temp2 += hw1_x[i];
	}

	result = HW1_N * temp1 - temp2 * temp2;
	hw1_var2 = result / HW1_N / (HW1_N - 1);
}


/* hw2 */
void hw2_naive()
{
	float ans1 = 0, ans2 = 0;
	ans1 = (-hw2_b + sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c)) / (2 * hw2_a);
	ans2 = (-hw2_b - sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c)) / (2 * hw2_a);

	hw2_naive_ans[0] = ans1;
	hw2_naive_ans[1] = ans2;
}
void hw2_safe()
{
	double ans1 = 0, ans2 = 0;
	
	if (hw2_b >= 0) {
		ans1 = (-4) * hw2_a * hw2_c;
		ans1 = ans1 / (hw2_b + sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c));
		ans1 = ans1 / (2 * hw2_a);

		ans2 = (-hw2_b) - sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c);
		ans2 = ans2 / (2 * hw2_a);

	}

	else {

		ans1 = (-hw2_b) + sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c);
		ans1 = ans1 / (2 * hw2_a);
		ans2 = (-4) * hw2_a * hw2_c;
		ans2 = ans2 / (hw2_b - sqrt(hw2_b * hw2_b - 4 * hw2_a * hw2_c));
		ans2 = ans2 / (2 * hw2_a);

	}

	hw2_pre_ans[0] = ans1;
	hw2_pre_ans[1] = ans2;
}
float hw2_verify(float x)
{
	return hw2_a * x * x + hw2_b*x + hw2_c;
}

void hw3_1(void) {
	int Array[ARRAY_SIZE];
	float run_time;
	printf("\n\n*****************************\n");
	printf("Strength Reduction\n");
	printf("*****************************\n");
	srand(time(NULL));
	for (int i = 0; i < ARRAY_SIZE; i++) {
		Array[i] = rand() % 1653;
	}

	CHECK_TIME_START;
	for (int i = 0; i < ARRAY_SIZE; i++) {
		Array[i] = i * 64 / 64 * 64 / 64 * 64 / 64 * 64 / 64;
	}

	CHECK_TIME_END(compute_time1);
	printf("The runtime before using Strength Reduction is %.3f(ms).\n", compute_time1 * 1000);

	CHECK_TIME_START;
	for (int i = 0; i < ARRAY_SIZE; i++) {
		Array[i] = i << 6 >> 6 << 6 >> 6 << 6 >> 6 << 6 >> 6;
	}

	CHECK_TIME_END(compute_time2);
	printf("The runtime after using Strength Reduction is %.3f(ms).\n", compute_time2 * 1000);
}

void hw3_2(void) {
	int Array[ARRAY_SIZE];
	int v1, v2, v3, v4, temp;
	
	printf("\n*****************************\n");
	printf("Loop Invariant Code Motion\n");
	printf("*****************************\n");
	srand(time(NULL));
	v1 = rand() / 165;
	v2 = rand() / 165;
	v3 = rand() / 165;
	v4 = rand() / 165;

	CHECK_TIME_START;
	for (int i = 0; i < ARRAY_SIZE; i++) {
		Array[i] = (v1 * v1) + (v2 * v2) + (v3 * v3) + (v4 * v4) + ARRAY_SIZE + i;
	}

	CHECK_TIME_END(compute_time1);
	printf("The runtime before using loop invarient cod motion is %.3f(ms).\n", compute_time1 * 1000);

	CHECK_TIME_START;
	temp = (v1 * v1) + (v2 * v2) + (v3 * v3) + (v4 * v4) + ARRAY_SIZE;
	for (int i = 0; i < ARRAY_SIZE; i++) {
		Array[i] = temp + 1;
	}

	CHECK_TIME_END(compute_time2);
	printf("The runtime after using loop invarient cod motion is %.3f(ms).\n", compute_time2 * 1000);

}

void hw3_3(void) {
	float Array[ARRAY_SIZE] = { 0, };
	int i = 0;

	printf("\n\n*****************************\n");
	printf("Use Local Instead of Global\n");
	printf("*****************************\n");

	CHECK_TIME_START;
	while (i < ARRAY_SIZE) {
		Arr_global[i] = i;
		i++;
	}

	CHECK_TIME_END(compute_time1);
	printf("The runtime using global variable is %.3f(ms).\n", compute_time1 * 1000);


	i = 0;
	CHECK_TIME_START;
	while (i < ARRAY_SIZE) {
		Array[i] = i;
		i++;
	}
	CHECK_TIME_END(compute_time2);

	printf("The runtime using local variable is %.3f(ms)\n", compute_time2 * 1000);
}

void hw3_4(void) {

	int Array_1[10000] = { 0, };
	int Array_2[10000] = { 0, };
	int Array_3[10000] = { 0, };
	int Array_4[10000] = { 0, };
	int i = 0;

	printf("\n\n*****************************\n");
	printf("Loop Inversion\n");
	printf("*****************************\n");


	CHECK_TIME_START;

	while (i < 10000) {

		Array_1[i] = i;
		Array_2[i] = Array_1[i] + i;
		i++;
	}

	CHECK_TIME_END(compute_time1);
	printf("The runtime before using loop inversion is %.3f(ms).\n", compute_time1 * 1000);

	i = 0;
	CHECK_TIME_START;

	if (i < 10000) {

		do {

			Array_3[i] = i;
			Array_4[i] = Array_3[i] + i;
			i++;
		} while (i < 10000);
	}
	CHECK_TIME_END(compute_time2);
	printf("The runtime after using loop inversion is %.3f(ms).\n", compute_time2 * 1000);
}

void hw3_5(void) { 

	printf("\n\n*****************************\n");
	printf("Use Eliminating Sub Expression\n");
	printf("*****************************\n");

	CHECK_TIME_START;
	float ret[100] = { 0, };
	float A, Y = 2;
	for (int i = 0; i < 100; i++)
		ret[i] = pow(pow(Y, 5), 5) * Y;

	CHECK_TIME_END(compute_time1);

	printf("The runtime after using Before eliminate is %.3f(ms)\n", compute_time1 * 1000);

	CHECK_TIME_START;
	A = pow(Y, 5);
	for (int i = 0; i < 100; i++)
		ret[i] = pow(A, 5) * Y;
	CHECK_TIME_END(compute_time2);

	printf("The runtime after using After eliminate is %.3f(ms)\n", compute_time2 * 1000);
}
